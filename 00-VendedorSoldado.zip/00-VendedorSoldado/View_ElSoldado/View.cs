﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain_Vendedor;
using Presenter_ElSoldado;

namespace View_ElSoldado
{
    public class View : IView
    {
        private readonly Presenter _Presenter;

        public View(){
            _Presenter = new Presenter(this);
            Show_main_menu();
        }

    #region "Métodos que contienen lógica de vista"
        private void Show_main_menu()
        {
            string opcion;
            bool salir = false;

            do
            {
                Console.Clear();
                Console.WriteLine("-== Bienvenido al Cotizador Express ==-");
                Console.WriteLine($"Tienda: {_Presenter._tienda.Nombre}. Dirección: {_Presenter._tienda.Direccion}");
                Console.WriteLine();
                Console.WriteLine($"Vendedor: {_Presenter._vendedor.Nombre} {_Presenter._vendedor.Apellido}. Código Vendedor: {_Presenter._vendedor.CodigoVendedor}");
                Console.WriteLine();
                Console.WriteLine("¿Qué desea hacer?");
                Console.WriteLine("(presione el número correspondiente a la opción del menú)");
                Console.WriteLine("");
                Console.WriteLine("1- Hacer una cotizacion");
                Console.WriteLine("2- Ver Historial de cotizaciones");
                Console.WriteLine("X- Salir");

                opcion = Console.ReadLine();

                SeleccionarAccion(opcion, ref salir);

            } while (salir == false);

        }
        private void SeleccionarAccion(string opcion, ref bool salir)
        {
            switch (opcion)
            {
                case "1":
                    MostrarMenuCotizar();
                    salir = false;
                    break;
                case "2":
                    Console.WriteLine("Este es el historial de cotizaciones");
                    _Presenter._cotizacion.MostrarHistorial(_Presenter._cotizacion.cotizaciones);
                    Console.ReadKey();
                    salir = false;
                    break;
                case "x":
                case "X":
                    Environment.Exit(2);
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    salir = false;
                    break;
            }
        }

        private void MostrarMenuCotizar()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja la prenda que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Camisa");
                Console.WriteLine("2- Pantalon");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarPrenda(opcion, ref opcionValida);

            } while (opcionValida == false);
            Show_main_menu();
        }

        private void SeleccionarPrenda(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    MostrarMenuManga();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    MostrarMenuChupin();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos al menú principal.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuManga()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja el tipo de manga que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Manga Larga");
                Console.WriteLine("2- Manga Corta");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarManga(opcion, ref opcionValida);

            } while (opcionValida == false);
            MostrarMenuCotizar();
        }

        private void SeleccionarManga(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    _Presenter._camisa.isMangaLarga = true;
                    MostrarMenuCuello();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    _Presenter._camisa.isMangaLarga = false;
                    MostrarMenuCuello();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos atrás.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuCuello()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja el tipo de cuello que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Cuello Mao");
                Console.WriteLine("2- Cuello Normal");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarCuello(opcion, ref opcionValida);

            } while (opcionValida == false);
            MostrarMenuManga();
        }

        private void SeleccionarCuello(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    _Presenter._camisa.isMao = true;
                    MostrarMenuCalidadCamisa();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    _Presenter._camisa.isMao = false;
                    MostrarMenuCalidadCamisa();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos atrás.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuCalidadCamisa()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja la calidad de prenda que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Standard");
                Console.WriteLine("2- Premium");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarCalidadCamisa(opcion, ref opcionValida);

            } while (opcionValida == false);
            MostrarMenuCuello();
        }

        private void SeleccionarCalidadCamisa(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    _Presenter._camisa.isPremium = false;
                    Console.WriteLine($"Hay {_Presenter._tienda.GetStockCamisa(_Presenter._camisa.isMangaLarga, _Presenter._camisa.isMao, _Presenter._camisa.isPremium)} unidades en stock");
                    Console.WriteLine("¿Que cantidad desea cotizar?");
                    MostrarMenuCantidadCamisa();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    _Presenter._camisa.isPremium = true;
                    Console.WriteLine($"Hay {_Presenter._tienda.GetStockCamisa(_Presenter._camisa.isMangaLarga, _Presenter._camisa.isMao, _Presenter._camisa.isPremium)} unidades en stock");
                    Console.WriteLine("¿Que cantidad desea cotizar?");
                    MostrarMenuCantidadCamisa();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos atrás.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuCantidadCamisa()
        {
            //Console.Clear();
            Console.WriteLine("Por favor, ingrese la cantidad de prendas que desea cotizar:");
            Console.WriteLine("");

            var cantidad = int.Parse(Console.ReadLine());

            if (_Presenter._tienda.InStockCamisa(_Presenter._camisa.isMangaLarga, _Presenter._camisa.isMao, _Presenter._camisa.isPremium, cantidad))
            {
                var precio = _Presenter._cotizacion.CalcularPrecioCamisa(_Presenter._camisa.isMangaLarga, _Presenter._camisa.isMao, _Presenter._camisa.isPremium, cantidad);
                Console.WriteLine($"Cada prenda sale {precio}, y el total es {cantidad * precio}");

            }
            Console.WriteLine("Para volver al menu principal presione cualquier tecla");


            Console.ReadLine();
            Show_main_menu();
        }

        private void MostrarMenuChupin()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja el tipo de pantalón que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Chupin");
                Console.WriteLine("2- Clásico");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarChupin(opcion, ref opcionValida);

            } while (opcionValida == false);
            Show_main_menu();

        }

        private void SeleccionarChupin(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    _Presenter._pantalon.isChupin = true;
                    MostrarMenuCalidadPantalon();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    _Presenter._pantalon.isChupin = false;
                    MostrarMenuCalidadPantalon();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos atrás.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuCalidadPantalon()
        {
            string opcion;
            bool opcionValida = false;
            do
            {
                Console.Clear();
                Console.WriteLine("Por favor, escoja la calidad de prenda que desea cotizar:");
                Console.WriteLine("");
                Console.WriteLine("1- Standard");
                Console.WriteLine("2- Premium");
                Console.WriteLine("A- Volver atrás");

                opcion = Console.ReadLine();

                SeleccionarCalidadPantalon(opcion, ref opcionValida);

            } while (opcionValida == false);
            MostrarMenuCuello();
        }

        private void SeleccionarCalidadPantalon(string opcion, ref bool opcionValida)
        {
            switch (opcion)
            {
                case "1":
                    _Presenter._pantalon.isPremium = false;
                    Console.WriteLine($"Hay {_Presenter._tienda.GetStockPantalon(_Presenter._pantalon.isChupin, _Presenter._pantalon.isPremium)} unidades en stock");
                    Console.WriteLine("¿Que cantidad desea cotizar?");
                    MostrarMenuCantidadPantalon();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "2":
                    _Presenter._pantalon.isPremium = true;
                    Console.WriteLine($"Hay {_Presenter._tienda.GetStockPantalon(_Presenter._pantalon.isChupin, _Presenter._pantalon.isPremium)} unidades en stock");
                    Console.WriteLine("¿Que cantidad desea cotizar?");
                    MostrarMenuCantidadPantalon();
                    opcionValida = true;
                    Console.ReadKey();
                    break;
                case "a":
                case "A":
                    Console.WriteLine("Okay,... Volveremos atrás.");
                    Console.ReadKey();
                    opcionValida = true;
                    break;
                default:
                    Console.WriteLine("La opción ingresada es inválida, por favor reintente.");
                    Console.ReadKey();
                    opcionValida = false;
                    break;
            }
        }

        private void MostrarMenuCantidadPantalon()
        {
            //Console.Clear();
            Console.WriteLine("Por favor, ingrese la cantidad de prendas que desea cotizar:");
            Console.WriteLine("");

            var cantidad = int.Parse(Console.ReadLine());

            if (_Presenter._tienda.InStockPantalon(_Presenter._pantalon.isChupin, _Presenter._pantalon.isPremium, cantidad))
            {
                var precio = _Presenter._cotizacion.CalcularPrecioPantalon(_Presenter._pantalon.isChupin, _Presenter._pantalon.isPremium, cantidad);
                Console.WriteLine($"Cada prenda sale {precio}, y el total es {cantidad * precio}");
            }
            Console.WriteLine("Para volver al menu principal presione cualquier tecla");


            Console.ReadLine();
            Show_main_menu();
        }

        #endregion

        #region "Métodos implementados de la interfaz IView"
        public void Show_text(string texto)
        {
            Console.WriteLine(texto);
        }
        
    #endregion
    }
}
