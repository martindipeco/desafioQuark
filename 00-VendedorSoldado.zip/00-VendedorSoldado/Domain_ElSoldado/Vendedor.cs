﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public class Vendedor
    {
        private List<Cotizacion> cotizaciones;

        protected String _nombre = "";
        protected String _apellido = "";
        protected int _codigoVendedor;

        public Vendedor()
        {
            _nombre = "Fulanito";
            _apellido = "Cosme";
            _codigoVendedor = 456;
        }

        public String Nombre
        {
            get { return _nombre; }
        }

        public String Apellido
        {
            get { return _apellido; }
        }

        public int CodigoVendedor
        {
            get { return _codigoVendedor; }
        }
    }
}
