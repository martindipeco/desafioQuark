﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public class Pantalon : Prenda
    {
        public bool isChupin;
        public String nombre;

        public Pantalon(bool isChupin, bool isPremium)
        {
            this.isChupin = isChupin;
            this.isPremium = isPremium;
        }

        public Pantalon()
        {
            isChupin = true;
            isPremium = true;
            nombre = "Pantalon";
        }

        public bool IsChupin
        {
            get { return isChupin; }
        }
        public string Nombre
        {
            get { return nombre; }
        }
    }
}
