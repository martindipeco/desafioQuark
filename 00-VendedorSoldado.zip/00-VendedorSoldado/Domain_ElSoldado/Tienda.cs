﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public class Tienda
    {
        private Vendedor _vendedor;

        private List<Prenda> _prendas;

        private String _nombre;
        private String _direccion;

        //atributos de stock
        //Camisas
        private int stockCamisaMangaLargaCuelloMaoStandard = 75;
        private int stockCamisaMangaLargaCuelloMaoPremium = 75;

        private int stockCamisaMangaLargaCuelloNormalStandard = 175;
        private int stockCamisaMangaLargaCuelloNormalPremium = 175;

        private int stockCamisaMangaCortaCuelloMaoStandard = 100;
        private int stockCamisaMangaCortaCuelloMaoPremium = 100;

        private int stockCamisaMangaCortaCuelloNormalStandard = 150;
        private int stockCamisaMangaCortaCuelloNormalPremium = 150;

        //Pantalones
        private int stockPantalonChupinStandard = 750;
        private int stockPantalonChupinPremium = 750;

        private int stockPantalonClasicoStandard = 250;
        private int stockPantalonClasicoPremium = 250;

        public Tienda()
        {
            _nombre = "La Favorita";
            _direccion = "Av. SiempreViva 123";
        }

        public String Nombre
        {
            get { return _nombre; }
        }

        public String Direccion
        {
            get { return _direccion; }
        }

        public int GetStockCamisa(bool isMangaLarga, bool isMao, bool isPremium)
        {
            if (isMao && isMangaLarga && isPremium)
            {
                return stockCamisaMangaLargaCuelloMaoPremium;
            }
            else if (isMao && isMangaLarga && !isPremium)
            {
                return stockCamisaMangaLargaCuelloMaoStandard;
            }
            else if (!isMao && isMangaLarga && isPremium)
            {
                return stockCamisaMangaLargaCuelloNormalPremium;
            }
            else if (!isMao && isMangaLarga && !isPremium)
            {
                return stockCamisaMangaLargaCuelloNormalStandard;
            }
            else if (isMao && !isMangaLarga && isPremium)
            {
                return stockCamisaMangaCortaCuelloMaoPremium;
            }
            else if (isMao && !isMangaLarga && !isPremium)
            {
                return stockCamisaMangaCortaCuelloMaoStandard;
            }
            else if (!isMao && !isMangaLarga && isPremium)
            {
                return stockCamisaMangaCortaCuelloNormalPremium;
            }
            else
            {
                return stockCamisaMangaCortaCuelloNormalStandard;
            }
        }

        public bool InStockCamisa(bool isMangaLarga, bool isMao, bool isPremium, int cantidad)
        {
            if (isMao && isMangaLarga && isPremium && cantidad > stockCamisaMangaLargaCuelloMaoPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (isMao && isMangaLarga && !isPremium && cantidad > stockCamisaMangaLargaCuelloMaoStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (!isMao && isMangaLarga && isPremium && cantidad > stockCamisaMangaLargaCuelloNormalPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (isMao && isMangaLarga && !isPremium && cantidad > stockCamisaMangaLargaCuelloNormalStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (isMao && !isMangaLarga && isPremium && cantidad > stockCamisaMangaCortaCuelloMaoPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (isMao && !isMangaLarga && !isPremium && cantidad > stockCamisaMangaCortaCuelloMaoStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (!isMao && !isMangaLarga && isPremium && cantidad > stockCamisaMangaCortaCuelloNormalPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (!isMao && !isMangaLarga && !isPremium && cantidad > stockCamisaMangaCortaCuelloNormalStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else
            {
                //Console.WriteLine("Hay Stock!");
                return true;
            }
        }

        public int GetStockPantalon(bool isChupin, bool isPremium)
        {
            if (isChupin && isPremium)
            {
                return stockPantalonChupinPremium;
            }
            else if (isChupin && !isPremium)
            {
                return stockPantalonChupinStandard;
            }
            else if (!isChupin && isPremium)
            {
                return stockPantalonClasicoPremium;
            }
            else
            {
                return stockPantalonClasicoStandard;
            }
        }

        public bool InStockPantalon(bool isChupin, bool isPremium, int cantidad)
        {
            if (isChupin && isPremium && cantidad > stockPantalonChupinPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (isChupin && !isPremium && cantidad > stockPantalonChupinStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (!isChupin && isPremium && cantidad > stockPantalonClasicoPremium)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else if (!isChupin && !isPremium && cantidad > stockPantalonClasicoStandard)
            {
                Console.WriteLine("No hay Stock :(");
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
