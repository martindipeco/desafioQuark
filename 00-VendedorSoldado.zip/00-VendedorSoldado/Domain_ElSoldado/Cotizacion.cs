﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public class Cotizacion
    {
        Random random = new Random(); // para simular código de cotización

        protected Vendedor _vendedor = new Vendedor();

        private int _idCotiz;
        private DateTime _fecha;
        private int _codigoVendedor;
        private Prenda _prenda;
        private Camisa _camisa;
        private Pantalon _pantalon;
        private int _cantidad;
        private float _precio;

        public List<Cotizacion> cotizaciones = new List<Cotizacion>();


        public Cotizacion(int codVend, Prenda prenda, int cant, float precio)
        {
            this._idCotiz = random.Next(0, 999);
            this._fecha = DateTime.Now;
            this._codigoVendedor = codVend;
            this._prenda = prenda;
            this._cantidad = cant;
            this._precio = precio;
        }

        public Cotizacion()
        {
            _idCotiz = random.Next(0, 999);
            _fecha = DateTime.Now;
            _codigoVendedor = 456;
            _prenda = _camisa;
            _cantidad = 1;
            _precio = 1;
        }

        public int IdCotiz
        {
            get { return _idCotiz; }
        }

        public DateTime Fecha
        {
            get { return _fecha; }
        }

        public int CodVend
        {
            get { return _codigoVendedor; }
        }

        public Prenda Prenda_
        {
            get { return _prenda; }
        }

        public int Cantidad
        {
            get { return _cantidad; }
        }

        public float Precio
        {
            get { return _precio; }
        }

        //Caso de uso que debe ser invocado por Presenter
        public void MostrarHistorial(List<Cotizacion> cotizaciones)
        {
            foreach (Cotizacion c in cotizaciones)
            {
                Console.WriteLine($"Id: {c.IdCotiz}, fecha: {c.Fecha}, cod. vendedor: {c.CodVend}, Prenda: {c.Prenda_}, Cant.: {c.Cantidad}, Precio x uni: {c.Precio}");
            }
        }

        //Caso de uso que debe ser invocado por Presenter
        public float CalcularPrecioCamisa(bool isMangaLarga, bool isMao, bool isPremium, int cantidad)
        {
            //asumimos para el caso que el precio unitario inicial = 100
            float precio = 100;

            if (!isMangaLarga)
            {
                precio = precio - (precio * 0.1f);
            }
            if (isMao)
            {
                precio = precio + (precio * 0.03f);
            }
            if (isPremium)
            {
                precio = precio + (precio * 0.3f);
            }
            Cotizacion cotizacion = new Cotizacion(_vendedor.CodigoVendedor, this._camisa, cantidad, precio);
            cotizaciones.Add(cotizacion);
            return precio;
        }

        //Caso de uso que debe ser invocado por Presenter
        public float CalcularPrecioPantalon(bool isChupin, bool isPremium, int cantidad)
        {
            //asumimos para el caso que el precio unitario es una constante = 100
            float precio = 100;

            if (isChupin)
            {
                precio = precio - (precio * 0.12f);
            }
            if (isPremium)
            {
                precio = precio + (precio * 0.3f);
            }
            Cotizacion cotizacion = new Cotizacion(_vendedor.CodigoVendedor, _pantalon, cantidad, precio);
            cotizaciones.Add(cotizacion);
            return precio;
        }
    }
}
