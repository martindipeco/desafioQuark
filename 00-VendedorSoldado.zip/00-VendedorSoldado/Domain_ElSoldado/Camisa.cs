﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public class Camisa : Prenda
    {
        public bool isMao;
        public bool isMangaLarga;
        public String nombre;

        public Camisa(bool isMangaLarga, bool isMao, bool isPremium)
        {
            this.isMangaLarga = isMangaLarga;
            this.isMao = isMao;
            this.isPremium = isPremium;
        }

        public Camisa()
        {
            isMangaLarga = true;
            isMao = true;
            isPremium = true;
            nombre = "Camisa";
        }


        public bool IsMangaLarga
        {
            get { return isMangaLarga; }
        }

        public bool IsMao
        {
            get { return isMao; }
        }

        public string Nombre
        {
            get { return nombre; }
        }
    }
}
