﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain_Vendedor
{
    public abstract class Prenda
    {
        protected float precioUnitario;
        public bool isPremium;
        public String nombre;

        public Prenda()
        {
            precioUnitario = 100;
        }

        public Prenda(bool isPremium)
        {
            this.isPremium = isPremium;
            this.precioUnitario = 100;
        }

        public float PrecioUnitario
        {
            get { return precioUnitario; }
        }

        public bool IsPremium
        {
            get { return isPremium; }
        }

    }
}
