﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Domain_Vendedor;

namespace Presenter_ElSoldado
{
    public class Presenter
    {
        public Vendedor _vendedor; // es necesario acceder a la clase vendedor que forma parte del Dominio
        public Tienda _tienda;
        public Cotizacion _cotizacion;
        public Camisa _camisa;
        public Pantalon _pantalon;

        private readonly IView _view;

        public Presenter(IView view)
        {
            _vendedor = new Vendedor();
            _tienda = new Tienda();
            _cotizacion = new Cotizacion();
            _camisa = new Camisa();
            _pantalon = new Pantalon();
            _view = view;
        }

        #region "Casos de Uso"
        // Los siguientes métodos representan "caso de uso". si bien se podrían codear a parte
        // (es decir, una clase por cada caso de uso), son tan pequeños y tienen tan poca lógica
        // de aplicación que no vale la pena separarlos de este presentador.
        /*
        public void Disparar() 
        {
            string disparo = _soldado.Disparar();
            _view.Show_text(disparo);
        }

        public void VerArma()
        {
            string nombreArma = _soldado.VerArma();
            _view.Show_text("El soldado está equipado con un/a "+nombreArma);
        }

        public void DejarArma()
        {
            _view.Show_text(_soldado.DejarArma());
        }

        public void RecogerArma(int opcionSeleccionada) 
        {
            _view.Show_text(_soldado.RecogerArma(opcionSeleccionada));
        }
        */
        #endregion

        // Muestra las opciones del menú que permiten seleccionar un arma, por ejemplo:
        // 1- Revolver
        // 2- Rifle
        // 3- Escopeta
        // 4- ...
        
        

    }
}
